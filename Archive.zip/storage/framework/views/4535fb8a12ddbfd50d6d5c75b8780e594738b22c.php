testing
<?php /**PATH /Users/smsc/Documents/Development/Projects/kayakadventure/resources/views/contactMail.blade.php ENDPATH**/ ?>